"""
DNSGuard feature extraction v4 (v3: policy signal dom_clients_1h; v4: session features cs_* averaged per device and domain over 1 h) — ONE implementation shared by training (Kaggle) and the live system.

Changes from v1 (see the training notebook, section "why v2"):
  * v2 lexical features look ONLY at the subdomain part and are case-insensitive.
    v1 used the registrable domain (sld_entropy, q_len, max_label_len, n_labels) and the letter case
    (upper_ratio, mixed_case). With only 15 attacker domains in the training data these became shortcuts:
    the v1 model memorised the attacker domains and "upper case = attack", and scored lowercase Base32
    payloads under a new domain as benign. DNS is case-insensitive, and resolvers may randomise case (0x20).
  * new generic encoding features: English-bigram ratio, digit/letter switching rate.
  * new 1-hour behavioural features per (client, domain) and per domain, counting NEW subdomains only,
    to catch low-and-slow exfiltration. They store only "new subdomain" events, so memory stays small
    for popular domains that reuse the same names.
  * running sums in the streaming featuriser (O(1) per query instead of O(window)).

v1 features are still computed so the notebook can compare v1 and v2 on identical data.

`batch_features(df)` (training) and `StreamFeaturizer.update(...)` (live) produce the same columns.
"""
from __future__ import annotations

import math
import string
from collections import Counter, OrderedDict, deque

import numpy as np
import pandas as pd

FEATURE_VERSION = "4.0"
WINDOW_S = 60
LONG_S = 3600

MULTI_TLD = {
    "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.jp", "co.kr", "co.in",
    "com.br", "com.cn", "com.tr", "com.sa", "com.eg", "com.iq", "gov.iq", "edu.iq", "org.iq", "net.iq",
    "com.jo", "com.lb", "co.za", "com.mx", "com.ar",
}
HEX = set("0123456789abcdef")
B32 = set("abcdefghijklmnopqrstuvwxyz234567")
VOWELS = set("aeiou")
LETTERS = set(string.ascii_lowercase)
DIGITS = set("0123456789")
CONSONANTS = LETTERS - VOWELS
BIGRAMS = set("th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou io le ve co "
              "me de hi ri ro ic ne ea ra ce li ch ll be ma si om ur ca el ta la ns ge ly ei os no pe do su pa "
              "ec ac ot di ol tr sh na lo".split())

# ---- v1 (kept for the before/after comparison) ----
LEXICAL_V1 = [
    "q_len", "sub_len", "n_labels", "max_label_len", "mean_label_len", "sub_entropy", "sld_entropy",
    "digit_ratio", "upper_ratio", "hyphen_ratio", "special_ratio", "vowel_ratio", "unique_char_ratio",
    "max_digit_run", "max_consonant_run", "hex_ratio", "is_hex_label", "is_b32_label", "mixed_case",
    "longest_label_entropy",
]
WINDOW = ["dom_q_w", "dom_newsub_w", "dom_subbytes_w", "dom_newsub_ratio_w", "dom_mean_sublen_w",
          "cli_dom_q_w", "cli_dom_newsub_w"]
FEATURES_V1 = LEXICAL_V1 + WINDOW

# ---- v2: subdomain-only, case-insensitive ----
LEXICAL_V2 = [
    "sub_len", "n_sub_labels", "max_sub_label_len", "mean_sub_label_len", "sub_entropy",
    "longest_label_entropy", "digit_ratio", "hyphen_ratio", "special_ratio", "vowel_ratio",
    "unique_char_ratio", "max_digit_run", "max_consonant_run", "hex_ratio", "is_hex_label", "is_b32_label",
    "bigram_ratio", "digit_letter_switch",
]
LONG = ["cli_dom_newsub_1h", "cli_dom_newbytes_1h", "dom_newsub_1h", "dom_newbytes_1h"]
FEATURES_V2 = LEXICAL_V2 + WINDOW + LONG
LEXICAL = LEXICAL_V2
FEATURES = FEATURES_V2
ALL_LEXICAL = list(dict.fromkeys(LEXICAL_V1 + LEXICAL_V2))
# policy-only signal (NOT a model feature): how many distinct devices queried this domain in the last hour.
# Popular-in-this-network domains are suppressed by the live policy; a tunnel is normally one device.
POLICY = ["dom_clients_1h"]
# v4 session features: averages of the lexical signals over ALL queries from one device to one domain in the
# last hour. They describe the conversation, not a single name, and do not depend on the attack rate
# (an average is the same whether the device sends 1 query per second or 1 per minute). The query count is
# deliberately NOT included, so these features cannot learn "many queries = attack".
SESSION_SRC = {"cs_mean_entropy_1h": "sub_entropy", "cs_mean_sublen_1h": "sub_len",
               "cs_mean_lle_1h": "longest_label_entropy", "cs_mean_maxlabel_1h": "max_sub_label_len",
               "cs_enc_frac_1h": "_enc", "cs_mean_bigram_1h": "bigram_ratio",
               "cs_mean_switch_1h": "digit_letter_switch", "cs_mean_digit_1h": "digit_ratio"}
SESSION = list(SESSION_SRC)
FEATURES_V4 = FEATURES_V2 + SESSION
BEHAVIOURAL = WINDOW + LONG + SESSION
# monotone constraints: behavioural counts may only RAISE suspicion (used by the "+mono" model)
MONOTONE = {f: 1 for f in ["dom_q_w", "dom_newsub_w", "dom_subbytes_w", "dom_newsub_ratio_w",
                           "cli_dom_q_w", "cli_dom_newsub_w"] + LONG}


def split_name(q: str):
    """-> (registrable domain, subdomain part, list of labels). Case is preserved in the subdomain."""
    q = (q or "").strip().rstrip(".")
    labels = [l for l in q.split(".") if l]
    low = [l.lower() for l in labels]
    k = 3 if (len(low) >= 3 and ".".join(low[-2:]) in MULTI_TLD) else 2
    k = min(k, len(labels))
    dom = ".".join(low[-k:]) if labels else ""
    sub = ".".join(labels[:-k]) if len(labels) > k else ""
    return dom, sub, labels


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    c = Counter(s)
    n = len(s)
    return -sum(v / n * math.log2(v / n) for v in c.values())


def _max_run(s: str, charset) -> int:
    best = cur = 0
    for ch in s:
        cur = cur + 1 if ch in charset else 0
        best = max(best, cur)
    return best


def lexical(q: str) -> dict:
    """All lexical features (v1 and v2) for one query name."""
    dom, sub, labels = split_name(q)
    s = sub.replace(".", "")
    sl = s.lower()
    n = max(len(s), 1)
    lens = [len(l) for l in labels] or [0]
    sub_labels = [l.lower() for l in sub.split(".") if l]
    sub_lens = [len(l) for l in sub_labels] or [0]
    ll = max(sub_labels, key=len) if sub_labels else ""
    sld_label = dom.split(".")[0] if dom else ""
    letters = sum(ch in LETTERS for ch in sl)
    pairs = [sl[i:i + 2] for i in range(len(sl) - 1)]
    letter_pairs = [p for p in pairs if p[0] in LETTERS and p[1] in LETTERS]
    switches = sum((a in DIGITS) != (b in DIGITS) for a, b in zip(sl, sl[1:])) if len(sl) > 1 else 0
    return {
        # shared / v2
        "sub_len": len(s),
        "n_sub_labels": len(sub_labels),
        "max_sub_label_len": max(sub_lens),
        "mean_sub_label_len": float(np.mean(sub_lens)),
        "sub_entropy": _entropy(sl),
        "longest_label_entropy": _entropy(ll),
        "digit_ratio": sum(ch.isdigit() for ch in s) / n,
        "hyphen_ratio": s.count("-") / n,
        "special_ratio": sum(not ch.isalnum() and ch != "-" for ch in s) / n,
        "vowel_ratio": sum(ch in VOWELS for ch in sl) / max(letters, 1),
        "unique_char_ratio": len(set(sl)) / n,
        "max_digit_run": _max_run(sl, DIGITS),
        "max_consonant_run": _max_run(sl, CONSONANTS),
        "hex_ratio": sum(ch in HEX for ch in sl) / n,
        "is_hex_label": int(len(ll) >= 16 and set(ll) <= HEX),
        "is_b32_label": int(len(ll) >= 16 and set(ll) <= B32 and any(ch.isdigit() for ch in ll)),
        "bigram_ratio": (sum(p in BIGRAMS for p in letter_pairs) / len(letter_pairs)) if letter_pairs else 0.0,
        "digit_letter_switch": switches / max(len(sl) - 1, 1),
        # v1 only
        "q_len": len(q.strip().rstrip(".")),
        "n_labels": len(labels),
        "max_label_len": max(lens),
        "mean_label_len": float(np.mean(lens)),
        "sld_entropy": _entropy(sld_label),
        "upper_ratio": sum(ch.isupper() for ch in s) / n,
        "mixed_case": int(any(ch.isupper() for ch in s) and any(ch.islower() for ch in s)),
    }


def lexical_frame(qnames: pd.Series) -> pd.DataFrame:
    """Lexical features for a column of query names (computed once per unique name)."""
    q = qnames.astype(str)
    uniq = pd.Series(q.unique())
    feats = pd.DataFrame([lexical(x) for x in uniq], index=uniq.values)
    return feats.loc[q.values].reset_index(drop=True)


def to_seconds(ts: pd.Series) -> pd.Series:
    """Timestamps (datetime, epoch seconds or strings) -> float epoch seconds."""
    def _sec(dt):   # works for any datetime64 resolution (ns, us, ms, s)
        dt = pd.to_datetime(dt, errors="coerce")
        if getattr(dt.dt, "tz", None) is not None:
            dt = dt.dt.tz_convert(None)
        return (dt - pd.Timestamp("1970-01-01")) / pd.Timedelta(seconds=1)
    if pd.api.types.is_datetime64_any_dtype(ts):
        return _sec(ts)
    num = pd.to_numeric(ts, errors="coerce")
    if num.notna().mean() > 0.9:
        return num.astype(float)
    return _sec(ts)


def batch_features(df: pd.DataFrame, qcol: str, tcol: str | None = None, ccol: str | None = None,
                   window_s: int = WINDOW_S, long_s: int = LONG_S) -> pd.DataFrame:
    """Training-time features. df rows = DNS queries. Returns all features (+ 'domain', 'sub') aligned to df."""
    q = df[qcol].astype(str)
    out = lexical_frame(q)
    parts = q.map(split_name)
    out["domain"] = [p[0] for p in parts]
    out["sub"] = [p[1].lower() for p in parts]
    if tcol is None:
        for c in BEHAVIOURAL + POLICY:
            out[c] = np.nan
        return out
    sec = to_seconds(df[tcol]).values
    w = pd.DataFrame({"sec": np.asarray(sec, dtype=float), "domain": out["domain"].values,
                      "sub": out["sub"].values, "sub_len": out["sub_len"].values.astype(float),
                      "cli": df[ccol].astype(str).values if ccol else "all"})
    for c, src in SESSION_SRC.items():
        w["s_" + c] = (np.maximum(out["is_hex_label"].values, out["is_b32_label"].values) if src == "_enc"
                       else out[src].values).astype(float)
    w.index = np.arange(len(w))           # index = original row position (unique), used to realign results
    w = w.dropna(subset=["sec"]).sort_values("sec", kind="mergesort")
    w["one"] = 1.0
    # first time this (domain, subdomain) is seen = new subdomain (streaming equivalent: seen-set per domain)
    w["new"] = (~w.duplicated(["domain", "sub"])).astype(float)
    w["newbytes"] = w["new"] * w["sub_len"]
    cols = ["one", "new", "sub_len", "newbytes"] + ["s_" + c for c in SESSION]
    tsec = w["sec"].values
    vals = w[cols].values.astype(float)

    def roll(keys, win):
        # sums over the time window (t - win, t] per key, with exactly the same rule as the stream
        # (an event expires when its ts <= t - win). Pure numpy, independent of the pandas version.
        code = np.zeros(len(w), dtype=np.int64)
        for k in keys:
            c, u = pd.factorize(w[k].values)
            code = code * (len(u) + 1) + c
        order = np.lexsort((np.arange(len(w)), tsec, code))      # by key, then time, then arrival order
        cs, ts = code[order], tsec[order]
        starts = np.r_[0, np.flatnonzero(np.diff(cs)) + 1]
        ends = np.r_[starts[1:], len(cs)]
        lo = np.arange(len(cs))
        for a, b in zip(starts, ends):
            if b - a > 1:
                lo[a:b] = a + np.searchsorted(ts[a:b], ts[a:b] - win, side="right")
        cum = np.vstack([np.zeros((1, len(cols))), np.cumsum(vals[order], axis=0)])
        sums = cum[np.arange(1, len(cs) + 1)] - cum[lo]
        out_ = np.empty_like(sums)
        out_[order] = sums
        return pd.DataFrame(out_, columns=cols, index=w.index)

    ws, ls = window_s, long_s
    r = roll(["domain"], ws)
    w["dom_q_w"], w["dom_newsub_w"], w["dom_subbytes_w"] = r["one"], r["new"], r["sub_len"]
    r = roll(["domain"], ls)
    w["dom_newsub_1h"], w["dom_newbytes_1h"] = r["new"], r["newbytes"]
    r = roll(["cli", "domain"], ws)
    w["cli_dom_q_w"], w["cli_dom_newsub_w"] = r["one"], r["new"]
    r = roll(["cli", "domain"], ls)
    w["cli_dom_newsub_1h"], w["cli_dom_newbytes_1h"] = r["new"], r["newbytes"]
    for c in SESSION:
        w[c] = r["s_" + c] / r["one"]
    w["dom_newsub_ratio_w"] = w["dom_newsub_w"] / w["dom_q_w"]
    w["dom_mean_sublen_w"] = w["dom_subbytes_w"] / w["dom_q_w"]
    w["dom_clients_1h"] = _distinct_clients(w, tsec, long_s)
    for c in BEHAVIOURAL + POLICY:
        out[c] = np.nan
        out.loc[w.index, c] = w[c].values
    return out


def _distinct_clients(w, tsec, L):
    """Per row: number of distinct clients that queried the row's domain in (t - L, t] (row's own client included).
    Same rule as the stream: a client stays active while last_query + L > t."""
    n = len(w)
    cd, ud = pd.factorize(w["domain"].values)
    cc, uc = pd.factorize(w["cli"].values)
    pair = cd.astype(np.int64) * (len(uc) + 1) + cc
    pos = np.arange(n)
    o = np.lexsort((pos, tsec, pair))                       # by (domain, client), time, arrival
    pp, tt = pair[o], tsec[o]
    same_prev = np.r_[False, pp[1:] == pp[:-1]]
    same_next = np.r_[pp[1:] == pp[:-1], False]
    prev_t = np.r_[np.nan, tt[:-1]]
    next_t = np.r_[tt[1:], np.nan]
    start = ~same_prev | (prev_t + L <= tt)                 # client (re)enters the window
    is_end = ~same_next | (tt + L <= next_t)                # last query of a run
    start_flag = np.zeros(n); start_flag[o] = start
    end_rows = o[is_end]
    end_time, end_dom = tt[is_end] + L, cd[end_rows]
    # per domain, in time order: cumulative starts minus runs that already ended (end_time <= t)
    od = np.lexsort((pos, tsec, cd))
    dsort, tsort = cd[od], tsec[od]
    cum = np.zeros(n)
    eo = np.lexsort((end_time, end_dom)); ed, et = end_dom[eo], end_time[eo]
    b0 = np.r_[0, np.flatnonzero(np.diff(dsort)) + 1]; b1 = np.r_[b0[1:], n]
    e_starts = np.searchsorted(ed, dsort[b0], side="left"); e_ends = np.searchsorted(ed, dsort[b0], side="right")
    sf = start_flag[od]
    for a, b, ea, eb in zip(b0, b1, e_starts, e_ends):
        c = np.cumsum(sf[a:b])
        if eb > ea:
            c = c - np.searchsorted(et[ea:eb], tsort[a:b], side="right")
        cum[a:b] = c
    out = np.empty(n); out[od] = cum
    return out


class _Win:
    """Sliding window with running sums: events (ts, a, b, ...)."""
    __slots__ = ("dq", "sums")

    def __init__(self, k):
        self.dq = deque()
        self.sums = [0.0] * k

    def add(self, ts, vals, horizon):
        self.dq.append((ts, vals))
        for i, v in enumerate(vals):
            self.sums[i] += v
        self.expire(ts, horizon)

    def expire(self, ts, horizon):
        dq, s = self.dq, self.sums
        while dq and dq[0][0] <= ts - horizon:
            _, vals = dq.popleft()
            for i, v in enumerate(vals):
                s[i] -= v


class StreamFeaturizer:
    """Live equivalent of batch_features: call update() for each query in time order."""

    def __init__(self, window_s: int = WINDOW_S, long_s: int = LONG_S, max_domains: int = 50_000,
                 max_subs: int = 20_000):
        self.window_s, self.long_s = window_s, long_s
        self.max_domains, self.max_subs = max_domains, max_subs
        self.dom = OrderedDict()       # domain -> _Win[(one, sub_len, new)]  (60 s)
        self.cli = OrderedDict()       # (client, domain) -> _Win[(one, new)]  (60 s)
        self.dom_l = OrderedDict()     # domain -> _Win[(new, newbytes)]  (1 h, only new-subdomain events)
        self.cli_l = OrderedDict()     # (client, domain) -> _Win[(new, newbytes)]  (1 h)
        self.seen = OrderedDict()      # domain -> OrderedDict(sub -> None)
        self.clients = OrderedDict()   # domain -> OrderedDict(client -> last ts), ordered by last ts (1 h)
        self.sess = OrderedDict()      # (client, domain) -> _Win[(one, session sources...)]  (1 h, all queries)

    def _touch(self, od, key, factory, cap):
        if key in od:
            od.move_to_end(key)
        else:
            od[key] = factory()
            if len(od) > cap:
                od.popitem(last=False)
        return od[key]

    def update(self, qname: str, ts: float, client: str = "all") -> dict:
        f = lexical(qname)
        dom, sub, _ = split_name(qname)
        sub = sub.lower()
        seen = self._touch(self.seen, dom, OrderedDict, self.max_domains)
        new = 0.0
        if sub not in seen:
            new = 1.0
            seen[sub] = None
            if len(seen) > self.max_subs:
                seen.popitem(last=False)
        sl = float(f["sub_len"])
        D = self._touch(self.dom, dom, lambda: _Win(3), self.max_domains)
        D.add(ts, (1.0, sl, new), self.window_s)
        C = self._touch(self.cli, (client, dom), lambda: _Win(2), self.max_domains * 4)
        C.add(ts, (1.0, new), self.window_s)
        DL = self._touch(self.dom_l, dom, lambda: _Win(2), self.max_domains)
        CL = self._touch(self.cli_l, (client, dom), lambda: _Win(2), self.max_domains * 4)
        if new:
            DL.add(ts, (1.0, sl), self.long_s)
            CL.add(ts, (1.0, sl), self.long_s)
        else:
            DL.expire(ts, self.long_s)
            CL.expire(ts, self.long_s)
        SS = self._touch(self.sess, (client, dom), lambda: _Win(1 + len(SESSION)), self.max_domains * 4)
        enc = float(max(f["is_hex_label"], f["is_b32_label"]))
        SS.add(ts, (1.0,) + tuple(enc if src == "_enc" else float(f[src]) for src in SESSION_SRC.values()), self.long_s)
        cl = self._touch(self.clients, dom, OrderedDict, self.max_domains)
        cl.pop(client, None); cl[client] = ts
        while cl:
            k0 = next(iter(cl))
            if cl[k0] + self.long_s <= ts: cl.popitem(last=False)
            else: break
        n, subbytes, newsub = D.sums
        f.update({
            "dom_q_w": n, "dom_newsub_w": newsub, "dom_subbytes_w": subbytes,
            "dom_newsub_ratio_w": newsub / n, "dom_mean_sublen_w": subbytes / n,
            "cli_dom_q_w": C.sums[0], "cli_dom_newsub_w": C.sums[1],
            "dom_newsub_1h": DL.sums[0], "dom_newbytes_1h": DL.sums[1],
            "cli_dom_newsub_1h": CL.sums[0], "cli_dom_newbytes_1h": CL.sums[1],
            "dom_clients_1h": float(len(cl)),
        })
        nq = SS.sums[0]
        for i, c in enumerate(SESSION):
            f[c] = SS.sums[i + 1] / nq
        f["domain"], f["sub"] = dom, sub
        return f


# ---------- human-readable explanations (shared by notebook GUI and live system) ----------
REASONS = {
    "sub_entropy": ("high randomness in the subdomain", "عشوائية عالية بالاسم الفرعي"),
    "longest_label_entropy": ("a very random-looking label", "مقطع يبدو عشوائياً جداً"),
    "sub_len": ("a very long subdomain (data hidden in the name)", "اسم فرعي طويل جداً (بيانات مخفية بالاسم)"),
    "q_len": ("an unusually long query name", "اسم طلب طويل بشكل غير طبيعي"),
    "max_label_len": ("a label close to the 63-character limit", "مقطع قريب من حد الـ 63 حرف"),
    "max_sub_label_len": ("a label close to the 63-character limit", "مقطع قريب من حد الـ 63 حرف"),
    "mean_sub_label_len": ("consistently long labels", "مقاطع طويلة باستمرار"),
    "digit_ratio": ("many digits in the name", "أرقام كثيرة بالاسم"),
    "hex_ratio": ("hex-encoded characters", "ترميز ست عشري (Hex)"),
    "is_hex_label": ("a hex-encoded label", "مقطع مرمّز Hex"),
    "is_b32_label": ("a Base32-encoded label", "مقطع مرمّز Base32"),
    "mixed_case": ("mixed upper/lower case (Base64-like)", "حروف كبيرة وصغيرة مختلطة (يشبه Base64)"),
    "unique_char_ratio": ("high character diversity", "تنوّع عالي بالحروف"),
    "max_consonant_run": ("long runs of consonants (not a word)", "سلسلة حروف ساكنة طويلة (مو كلمة)"),
    "vowel_ratio": ("unusual vowel ratio", "نسبة حروف علة غير طبيعية"),
    "bigram_ratio": ("letters do not form natural words", "الحروف ما تكوّن كلمات طبيعية"),
    "digit_letter_switch": ("digits and letters interleaved like encoded data", "أرقام وحروف متداخلة مثل البيانات المرمّزة"),
    "n_labels": ("many dot-separated labels", "مقاطع كثيرة مفصولة بنقاط"),
    "n_sub_labels": ("many dot-separated labels", "مقاطع كثيرة مفصولة بنقاط"),
    "dom_q_w": ("many queries to this domain in the window", "طلبات كثيرة لنفس النطاق خلال فترة قصيرة"),
    "dom_newsub_w": ("many never-seen subdomains under one domain", "أسماء فرعية جديدة كثيرة تحت نفس النطاق"),
    "dom_newsub_ratio_w": ("almost every query uses a new subdomain", "تقريباً كل طلب يستخدم اسم فرعي جديد"),
    "dom_subbytes_w": ("a large volume of data encoded in names", "كمية بيانات كبيرة مرمّزة بالأسماء"),
    "dom_mean_sublen_w": ("consistently long subdomains to this domain", "أسماء فرعية طويلة باستمرار لنفس النطاق"),
    "cli_dom_q_w": ("one device querying this domain repeatedly", "جهاز واحد يكرر الطلب لنفس النطاق"),
    "cli_dom_newsub_w": ("one device generating many new subdomains", "جهاز واحد يولّد أسماء فرعية جديدة كثيرة"),
    "cs_mean_entropy_1h": ("this device's names to this domain are random on average", "أسماء هذا الجهاز لهذا النطاق عشوائية بالمعدل"),
    "cs_mean_sublen_1h": ("this device keeps sending long subdomains to this domain", "هذا الجهاز يرسل أسماء فرعية طويلة باستمرار لهذا النطاق"),
    "cs_mean_lle_1h": ("this device's labels look random on average", "مقاطع هذا الجهاز تبدو عشوائية بالمعدل"),
    "cs_mean_maxlabel_1h": ("this device keeps using near-maximum labels", "هذا الجهاز يستخدم مقاطع قريبة من الحد الأقصى باستمرار"),
    "cs_enc_frac_1h": ("most of this device's names look encoded", "أغلب أسماء هذا الجهاز تبدو مرمّزة"),
    "cs_mean_bigram_1h": ("this device's names are not natural words", "أسماء هذا الجهاز مو كلمات طبيعية"),
    "cs_mean_switch_1h": ("digits and letters interleaved across this device's names", "أرقام وحروف متداخلة بأسماء هذا الجهاز"),
    "cs_mean_digit_1h": ("many digits across this device's names", "أرقام كثيرة بأسماء هذا الجهاز"),
    "cli_dom_newsub_1h": ("one device sent many new subdomains over the last hour (slow leak)",
                          "جهاز واحد أرسل أسماء فرعية جديدة كثيرة خلال الساعة الأخيرة (تسريب بطيء)"),
    "cli_dom_newbytes_1h": ("one device encoded a lot of data in names over the last hour",
                            "جهاز واحد رمّز كمية بيانات كبيرة بالأسماء خلال الساعة الأخيرة"),
    "dom_newsub_1h": ("many new subdomains to this domain over the last hour",
                      "أسماء فرعية جديدة كثيرة لهذا النطاق خلال الساعة الأخيرة"),
    "dom_newbytes_1h": ("a lot of data encoded in names to this domain over the last hour",
                        "كمية بيانات كبيرة مرمّزة لهذا النطاق خلال الساعة الأخيرة"),
}


def explain(contrib: dict, top: int = 3, lang: str = "ar") -> list[str]:
    """contrib: feature -> contribution to the attack score (positive pushes towards attack)."""
    idx = 1 if lang == "ar" else 0
    pos = sorted([(v, k) for k, v in contrib.items() if v > 0 and k in REASONS], reverse=True)
    out = []
    for _, k in pos:
        r = REASONS[k][idx]
        if r not in out:
            out.append(r)
        if len(out) == top:
            break
    return out


def estimate_exfil_bytes(subbytes_chars: float, encoding: str = "base32") -> float:
    """Rough payload estimate from characters carried in subdomains."""
    ratio = {"hex": 0.5, "base32": 0.625, "base64": 0.75}.get(encoding, 0.6)
    return subbytes_chars * ratio
