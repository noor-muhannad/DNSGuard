"""
DNSGuard character-level CNN for the subdomain part of a query name (shared by training and the live system).

It reads the lower-cased SUBDOMAIN only (never the registrable domain), character by character, so it cannot
memorise attacker domains or letter case. Needs PyTorch; the live system can run it on CPU.
"""
from __future__ import annotations

import numpy as np

try:
    import torch
    import torch.nn as nn
except ImportError:  # the XGBoost-only bundle does not need torch
    torch = None
    nn = None

VOCAB = "abcdefghijklmnopqrstuvwxyz0123456789-_."
MAXLEN = 128
LUT = np.full(256, len(VOCAB) + 1, dtype=np.int64)     # unknown character
LUT[0] = 0                                             # padding
for i, ch in enumerate(VOCAB):
    LUT[ord(ch)] = i + 1


def encode(subs) -> np.ndarray:
    """list of lower-case subdomain strings -> int array (n, MAXLEN)."""
    b = b"".join(str(s).lower().encode("ascii", "ignore")[:MAXLEN].ljust(MAXLEN, b"\0") for s in subs)
    return LUT[np.frombuffer(b, dtype=np.uint8).reshape(-1, MAXLEN)]


if nn is not None:
    class CharCNNNet(nn.Module):
        def __init__(self, emb=32, ch=64, kernels=(3, 5, 7), hidden=64):
            super().__init__()
            self.emb = nn.Embedding(len(VOCAB) + 2, emb, padding_idx=0)
            self.convs = nn.ModuleList([nn.Conv1d(emb, ch, k, padding=k // 2) for k in kernels])
            self.head = nn.Sequential(nn.Linear(ch * len(kernels), hidden), nn.ReLU(), nn.Dropout(0.2), nn.Linear(hidden, 1))

        def forward(self, x):
            mask = (x > 0).float().unsqueeze(1)                    # ignore padding in the max-pool
            e = self.emb(x).transpose(1, 2)
            h = [torch.relu(c(e)) * mask - (1 - mask) * 1e4 for c in self.convs]
            h = torch.cat([t.max(dim=2).values.clamp(min=0) for t in h], dim=1)
            return self.head(h).squeeze(1)


class CharCNN:
    """sklearn-like wrapper: fit(subs, y) / predict_proba(subs)."""

    def __init__(self, epochs=3, batch=4096, lr=2e-3, seed=42, device=None):
        self.epochs, self.batch, self.lr, self.seed = epochs, batch, lr, seed
        self.device = device or ("cuda" if torch is not None and torch.cuda.is_available() else "cpu")

    def fit(self, subs, y):
        torch.manual_seed(self.seed); np.random.seed(self.seed)
        X = torch.tensor(encode(subs)); y = torch.tensor(np.asarray(y, np.float32))
        self.net = CharCNNNet().to(self.device)
        opt = torch.optim.AdamW(self.net.parameters(), lr=self.lr)
        pw = torch.tensor([(y == 0).sum().item() / max((y == 1).sum().item(), 1)], device=self.device)
        lossf = nn.BCEWithLogitsLoss(pos_weight=pw)
        for _ in range(self.epochs):
            self.net.train(); perm = torch.randperm(len(X))
            for k in range(0, len(X), self.batch):
                b = perm[k:k + self.batch]
                if len(b) < 2: continue
                xb, yb = X[b].to(self.device), y[b].to(self.device)
                opt.zero_grad(); lossf(self.net(xb), yb).backward(); opt.step()
        return self

    def predict_proba(self, subs):
        X = torch.tensor(encode(subs)); self.net.eval(); out = []
        with torch.no_grad():
            for k in range(0, len(X), 65536):
                out.append(torch.sigmoid(self.net(X[k:k + 65536].to(self.device))).cpu().numpy())
        p = np.concatenate(out) if out else np.zeros(0, np.float32)
        p[(X > 0).sum(1).numpy() == 0] = 0.0          # no subdomain -> nothing can be hidden in the name
        return np.c_[1 - p, p]

    def to_cpu(self):
        self.net = self.net.cpu(); self.device = "cpu"; return self

    def state(self):
        return {"state_dict": {k: v.cpu() for k, v in self.net.state_dict().items()}, "vocab": VOCAB, "maxlen": MAXLEN}

    @classmethod
    def from_state(cls, st, device="cpu"):
        m = cls(device=device); m.net = CharCNNNet(); m.net.load_state_dict(st["state_dict"]); m.net.to(device).eval()
        return m
